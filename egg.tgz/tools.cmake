# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(hollowpine src/hollowpine.cpp)
set_property(TARGET hollowpine PROPERTY CXX_STANDARD 11)
target_link_libraries(hollowpine lionss pthread)

add_executable(windowFrame src/windowFrame.cpp)
set_property(TARGET windowFrame PROPERTY CXX_STANDARD 11)
target_link_libraries(windowFrame lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(Vp9Svc src/Vp9Svc.cpp)
set_property(TARGET Vp9Svc PROPERTY CXX_STANDARD 11)
target_link_libraries(Vp9Svc lionss pthread)

add_executable(GiProbeBake src/GiProbeBake.cpp)
set_property(TARGET GiProbeBake PROPERTY CXX_STANDARD 11)
target_link_libraries(GiProbeBake lionss pthread)

add_executable(anf-lower src/anf-lower.cpp)
set_property(TARGET anf-lower PROPERTY CXX_STANDARD 11)
target_link_libraries(anf-lower lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(tiderun src/tiderun.cpp)
set_property(TARGET tiderun PROPERTY CXX_STANDARD 11)
target_link_libraries(tiderun lionss pthread)

add_executable(GliderFleet src/GliderFleet.cpp)
set_property(TARGET GliderFleet PROPERTY CXX_STANDARD 11)
target_link_libraries(GliderFleet lionss pthread)

add_executable(spill-tempfile src/spill-tempfile.cpp)
set_property(TARGET spill-tempfile PROPERTY CXX_STANDARD 11)
target_link_libraries(spill-tempfile lionss pthread)

add_executable(coldspring src/coldspring.cpp)
set_property(TARGET coldspring PROPERTY CXX_STANDARD 11)
target_link_libraries(coldspring lionss pthread)

add_executable(rtcpFeedback src/rtcpFeedback.cpp)
set_property(TARGET rtcpFeedback PROPERTY CXX_STANDARD 11)
target_link_libraries(rtcpFeedback lionss pthread)

add_executable(copper-moth src/copper-moth.cpp)
set_property(TARGET copper-moth PROPERTY CXX_STANDARD 11)
target_link_libraries(copper-moth lionss pthread)

add_executable(BloomThreshold src/BloomThreshold.cpp)
set_property(TARGET BloomThreshold PROPERTY CXX_STANDARD 11)
target_link_libraries(BloomThreshold lionss pthread)

add_executable(fft-window-hann src/fft-window-hann.cpp)
set_property(TARGET fft-window-hann PROPERTY CXX_STANDARD 11)
target_link_libraries(fft-window-hann lionss pthread)

add_executable(graphite-owl src/graphite-owl.cpp)
set_property(TARGET graphite-owl PROPERTY CXX_STANDARD 11)
target_link_libraries(graphite-owl lionss pthread)

add_executable(ResnetProbe src/ResnetProbe.cpp)
set_property(TARGET ResnetProbe PROPERTY CXX_STANDARD 11)
target_link_libraries(ResnetProbe lionss pthread)

add_executable(webrtcDtls src/webrtcDtls.cpp)
set_property(TARGET webrtcDtls PROPERTY CXX_STANDARD 11)
target_link_libraries(webrtcDtls lionss pthread)

add_executable(geohashPack src/geohashPack.cpp)
set_property(TARGET geohashPack PROPERTY CXX_STANDARD 11)
target_link_libraries(geohashPack lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(zonemapskip src/zonemapskip.cpp)
set_property(TARGET zonemapskip PROPERTY CXX_STANDARD 11)
target_link_libraries(zonemapskip lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

add_executable(shadowCascade4 src/shadowCascade4.cpp)
set_property(TARGET shadowCascade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(shadowCascade4 lionss pthread)

add_executable(predicate_pushdown src/predicate_pushdown.cpp)
set_property(TARGET predicate_pushdown PROPERTY CXX_STANDARD 11)
target_link_libraries(predicate_pushdown lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(I2cRecover src/I2cRecover.cpp)
set_property(TARGET I2cRecover PROPERTY CXX_STANDARD 11)
target_link_libraries(I2cRecover lionss pthread)

