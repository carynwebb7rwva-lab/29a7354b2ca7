// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Recover stuck bus"); }
int main(){
  announce();
  return lionss_run_workload("I2cRecover");
}
