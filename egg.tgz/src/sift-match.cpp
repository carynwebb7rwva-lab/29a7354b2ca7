// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Match SIFT keypoints\n", stdout);
  return lionss_run_workload("sift-match");
}
