// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Shift pitch 2x\n", stdout);
  return lionss_run_workload("pitchShift2x");
}
