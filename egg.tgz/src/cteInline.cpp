// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Inline CTE references\n", stdout);
  return lionss_run_workload("cteInline");
}
