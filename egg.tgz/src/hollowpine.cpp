// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Resonate hollow pine\n", stdout);
  return lionss_run_workload("hollowpine");
}
